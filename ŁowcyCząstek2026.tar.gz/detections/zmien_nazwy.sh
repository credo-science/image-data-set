#!/bin/bash

target_dir="zmienione_nazwy"

i=1
for f in $(ls *.png 2>/dev/null | sort -V); do
    cp "$f" "$target_dir/$i.png"
    i=$((i+1))
done

echo "Gotowe. Przetworzono $((i-1)) plików."
